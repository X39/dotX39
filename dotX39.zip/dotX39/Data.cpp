#include "Data.h"
namespace dotX39
{
	Data::Data()
	{
	}
	Data::~Data()
	{
	}
};