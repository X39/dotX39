#include "DocumentReader.h"
#include <fstream>
#include <vector>

using namespace std;
#define READINGMODE_NAME 0
#define READINGMODE_DATA 1
#define READINGMODE_ARGUMENT 2
#define READINGMODE_ARGUMENT_END 3
#define READER_BUFFERSIZE 256
#define SETREADINGMODE(MODE) readingMode_last = readingMode; readingMode = MODE;
namespace dotX39
{
	namespace DocumentReader
	{
		void readDocument(const std::string filePath, Node* out) NOEXCEPT(false)
		{//TODO: adjust the "throw" so that ALL pointer vectors are deleted!
			fstream doc(filePath, fstream::in);
			char s[READER_BUFFERSIZE];
			s[READER_BUFFERSIZE - 1] = '\0';
			char* c = 0x00;
			vector<Node*> curNodeTree;
			curNodeTree.push_back(out);
			bool commentFlag = false;
			unsigned int readingMode = READINGMODE_NAME;
			unsigned int readingMode_last = READINGMODE_NAME;
			string name;
			string argumentName;
			bool dataTag = false;
			DataTypes dataType = NA;
			string data;
			vector<Data*> argumentsData;
			if (!doc.is_open())
				throw exception("Cannot open file");
			while (!doc.read(s, READER_BUFFERSIZE).eof())
			{
				for (int i = 0; i < READER_BUFFERSIZE - 1; i++)
				{
					if (curNodeTree.size() < 1)
						throw exception("While parsing the document, the root node got closed");
					c = s + i;
					if (c == '\0')
						break;
					if (commentFlag)
					{
						if (c[0] == '*' && c[1] == '/')
							commentFlag = false;
						continue;
					}
					if (readingMode == READINGMODE_NAME)
					{
#pragma region node arguments
						if (c[0] == '(')
						{
							//We located an argument
						}
#pragma endregion
#pragma region new node
						if (c[0] == '{')
						{
							//We located a new node here
							Node* n = new Node(name);
							for (int j = 0; j < argumentsData.size(); j++)
								n->addArgument(argumentsData[j]);
							argumentsData.clear();
							curNodeTree.back()->addSubnode(n);
							curNodeTree.push_back(n);
							name.clear();
						}
						else if (c[0] == '}')
						{
							//Current node wants to be closed
							curNodeTree.pop_back();
						}
#pragma endregion
#pragma region new option data
						else if (c[0] == '=')
						{
							//We located some data for our node here
							SETREADINGMODE(READINGMODE_DATA);
						}
#pragma endregion
#pragma region new character for name
						else if (true)
						{
							//just another char ... lets add it
							if (isalnum(c[0]))
							{
								name.append(c, c);
							}
							else if (iscntrl(c[0]))
							{
								//just discard it as it is not allowed for node names
							}
							else
							{
								throw exception("found non alphanumeric char for node name, please correct the file");
							}
						}
#pragma endregion
						continue;
					}
					else if (readingMode == READINGMODE_DATA)
					{
#pragma region define datatype
						if (!dataTag)
						{//Searching DataTag
							if (c[0] == '['){ dataTag = true; dataType = DataTypes::ARRAY; }
							else if (c[0] == '"'){ dataTag = true; dataType = DataTypes::STRING; }
							else if (c[0] == '\''){ dataTag = true; dataType = DataTypes::STRING; }
							else if (c[0] == '\\'){ dataTag = true; dataType = DataTypes::STRING; }
							else if (c[0] >= '0' && c[0] <= '9'){ dataTag = true; dataType = DataTypes::SCALAR; }

							else if (c[0] == '(' || c[0] == ')'){ throw exception("Invalid argument tag when data tag was expected"); }
							else if (c[0] == '{' || c[0] == '}'){ throw exception("Invalid node tag when data tag was expected"); }
							else if (c[0] == ']'){ throw exception("Invalid close array tag when open array (or another data) tag was expected"); }
							else if (c[0] == ';'){ throw exception("Invalid end of line tag when data tag was expected"); }
							else if (c[0] == ':'){ throw exception("Invalid time seperator tag when data tag was expected"); }
							else if (c[0] == '.'){ throw exception("Invalid scalar/date seperator tag when data tag was expected"); }
							else if (c[0] == ','){ throw exception("Invalid seperator tag when data tag was expected"); }
						}
#pragma endregion
#pragma region parse data
						else
						{
							if (dataType == DataTypes::ARRAY)
							{
								char* cp;
								char* cp2;
								int j = 0;
								while (true)
								{
									cp = strchr(c, ']');
									if (cp == NULL)
										break;
									for (cp2 = cp; cp[-1] == '\\';)
									{
										j++;
										cp2 = cp2 - 1;
									}
									if (j % 2 == 1)
										break;
									i += strlen(cp) - strlen(c) + 1;
									c = cp + 1;
								}
								if (cp != NULL)
								{
									data.append(c, cp);
									i += strlen(cp) - strlen(c) + 1;
									c = cp + 1;
									if (c[0] != ';')
										throw exception("Unexpected character where lineTerminator should have been");
									if (readingMode_last == READINGMODE_NAME)
										curNodeTree.back()->addData(readBoolean(data, name));
									else
										argumentsData.push_back(readBoolean(data, name));
									SETREADINGMODE(readingMode_last)
								}
								else
								{
									data.append(c);
									i = READER_BUFFERSIZE;
								}
							}
							else if (dataType == DataTypes::BOOLEAN)
							{
								char* cp;
								while (true)
								{
									cp = strchr(c, ';');
									if (cp == NULL)
										break;
									else
										break;
								}
								if (cp != NULL)
								{
									data.append(c, cp);
									i += strlen(cp) - strlen(c) + 1;
									c = cp + 1;
									if (c[0] != ';')
										throw exception("Unexpected character where lineTerminator should have been");
									if (readingMode_last == READINGMODE_NAME)
										curNodeTree.back()->addData(readBoolean(data, name));
									else
										argumentsData.push_back(readBoolean(data, name));
									SETREADINGMODE(readingMode_last)
								}
								else
								{
									data.append(c);
									i = READER_BUFFERSIZE;
								}
							}
							else if (dataType == DataTypes::DATETIME)
							{
								char* cp;
								while (true)
								{
									cp = strchr(c, '\\');
									if (cp == NULL)
										break;
									else
										break;
								}
								if (cp != NULL)
								{
									data.append(c, cp);
									i += strlen(cp) - strlen(c) + 1;
									c = cp + 1;
									if (c[0] != ';')
										throw exception("Unexpected character where lineTerminator should have been");
									if (readingMode_last == READINGMODE_NAME)
										curNodeTree.back()->addData(readBoolean(data, name));
									else
										argumentsData.push_back(readBoolean(data, name));
									SETREADINGMODE(readingMode_last)
								}
								else
								{
									data.append(c);
									i = READER_BUFFERSIZE;
								}
							}
							else if (dataType == DataTypes::SCALAR)
							{
								char* cp;
								while (true)
								{
									cp = strchr(c, '\\');
									if (cp == NULL)
										break;
									else
										break;
								}
								if (cp != NULL)
								{
									data.append(c, cp);
									i += strlen(cp) - strlen(c) + 1;
									c = cp + 1;
									if (c[0] != ';')
										throw exception("Unexpected character where lineTerminator should have been");
									if (readingMode_last == READINGMODE_NAME)
										curNodeTree.back()->addData(readBoolean(data, name));
									else
										argumentsData.push_back(readBoolean(data, name));
									SETREADINGMODE(readingMode_last)
								}
								else
								{
									data.append(c);
									i = READER_BUFFERSIZE;
								}
							}
							else if (dataType == DataTypes::STRING)
							{
								char* cp;
								char* cp2;
								int j = 0;
								while (true)
								{
									cp = strchr(c, '"');
									if (cp == NULL)
									{
										cp = strchr(c, '\'');
										if (cp == NULL)
											break;
									}
									for (cp2 = cp; cp[-1] == '\\';)
									{
										j++;
										cp2 = cp2 - 1;
									}
									if (j % 2 == 1)
										break;
									i += strlen(cp) - strlen(c) + 1;
									c = cp + 1;
								}
								if (cp != NULL)
								{
									data.append(c, cp);
									i += strlen(cp) - strlen(c) + 1;
									c = cp + 1;
									if (c[0] != ';' && c[0] != ',')
										throw exception("Unexpected character where lineTerminator should have been");
									if (readingMode_last == READINGMODE_NAME)
										curNodeTree.back()->addData(readBoolean(data, name));
									else
										argumentsData.push_back(readBoolean(data, name));
									SETREADINGMODE(readingMode_last)
								}
								else
								{
									data.append(c);
									i = READER_BUFFERSIZE;
								}
							}
						}
						continue;
					}
#pragma endregion
#pragma region handle arguments
					else if (readingMode == READINGMODE_DATA)
					{
						//just another char ... lets add it
						if (c[0] == '=')
						{
							SETREADINGMODE(READINGMODE_DATA);
						}
						if (c[0] == ')')
						{
							SETREADINGMODE(READINGMODE_ARGUMENT_END);
						}
						if (isalnum(c[0]))
						{
							argumentName.append(c, c);
						}
						else if (iscntrl(c[0]))
						{
							//just discard it as it is not allowed for node names
						}
						else
						{
							throw exception("found non alphanumeric char for argument name, please correct the file");
						}
					}
					else if (readingMode == READINGMODE_ARGUMENT_END)
					{
						if (c[0] == ' ' || c[0] == '\r' || c[0] == '\n' || c[0] == '\t')
							continue;
						if (c[0] != ';' && c[0] != '{')
							throw exception("Undexpected character after arguments");
						if (c[0] == '{')
							i--;
						SETREADINGMODE(READINGMODE_NAME);
					}
#pragma endregion
				}
			}
			if (readingMode != READINGMODE_NAME)
				throw exception("Reached EOF before all parsing operations ended");
			if (curNodeTree.size() != 1)
				throw exception("Invalid node count at EOF");
		}
		void writeDocument(const std::string filePath, const Node& documentNode) NOEXCEPT(false)
		{

		}
		Data* readString(const std::string data, const std::string name) NOEXCEPT(false)
		{

		}
		Data* readScalar(const std::string data, const std::string name) NOEXCEPT(false)
		{

		}
		Data* readDateTime(const std::string data, const std::string name) NOEXCEPT(false)
		{

		}
		Data* readBoolean(const std::string data, const std::string name) NOEXCEPT(false)
		{

		}
		Data* readArray(const std::string data, const std::string name) NOEXCEPT(false)
		{

		}
	};
};